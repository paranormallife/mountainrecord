<div class="thmlv-widget-type-team">
	<?php the_post_thumbnail('thmlvWidget'); ?>
	<?php the_title('<h1>', '</h1>'); ?>
</div>